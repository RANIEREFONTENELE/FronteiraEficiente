fronteiraeficiente <- function(idsimulacao, columns, data) {

     sqlclauseInput = paste0("EXEC [DBO].[GETDATASIMULACAO] @IDSIMULACAO = '", as.character(idsimulacao), "'" )

     data <- gsub(",", " ", gsub(";", " ", as.character(data)))
     colunas <- unlist(strsplit(as.character(columns), ","))
     dados <- utils::read.table(text=gsub("(?<=[a-z])\\s+", "\n", data, perl=TRUE), header=FALSE, col.names = colunas)

     dados<-timeSeries::as.timeSeries(dados)

     tangencyportfolio = fPortfolio::tangencyPortfolio(dados, spec = fPortfolio::portfolioSpec(), constraints = "LongOnly")
     tangencyreturn <- tangencyportfolio@portfolio@portfolio$targetReturn['mean']
     tangencyrisk <-  tangencyportfolio@portfolio@portfolio$targetRisk['Cov']
     assets <- row.names(data.frame(tangencyportfolio@portfolio@portfolio$weights))
     tangencyweights <- tangencyportfolio@portfolio@portfolio$weights

     minvarianceportfolio = fPortfolio::minvariancePortfolio(dados, spec = fPortfolio::portfolioSpec(), constraints = "LongOnly")
     minvariancereturn <- minvarianceportfolio@portfolio@portfolio$targetReturn['mean']
     minvariancerisk <-  minvarianceportfolio@portfolio@portfolio$targetRisk['Cov']

     Frontier = fPortfolio::portfolioFrontier(dados)
     returnpoints <- Frontier@portfolio@portfolio$targetReturn[,1]
     riskpoints <- Frontier@portfolio@portfolio$targetRisk[,1]

     simulacaodetail <- paste(tangencyreturn, tangencyrisk, minvariancereturn, minvariancerisk, sep=",")
     assetlist <- paste(assets,collapse=",")
     weightlist <- paste(tangencyweights,collapse=",")
     returnpointslist <- paste(returnpoints,collapse=",")
     riskpointslist <- paste(riskpoints,collapse=",")

     sqlclauseOutput = paste0("DBO.SETDATASIMULACAO @IDSIMULACAO='", as.character(idsimulacao), "',",
                              "@SIMULACAODETAIL='", simulacaodetail, "',",
                              "@ASSETLIST='", assetlist, "',",
                              "@WEIGHTLIST='", weightlist, "',",
                              "@RETURNPOINTSLIST='", returnpointslist, "',",
                              "@RISKPOINTSLIST='", riskpointslist, "'")
     sqlclauseOutput <- gsub("X", "", sqlclauseOutput)

     #urlbase <- "https://horusadm.kircinus.com.br/getsimulationresult.aspx"
     #argumento1 <- as.character(idsimulacao)
     #argumento2 <- URLencode(sqlclauseOutput, reserved = TRUE)
     argumento2 <- sqlclauseOutput

     #r <- httr::POST(urlbase, body = list(x = argumento1, y = argumento2), encode = "form", verbose())

     return (argumento2)
}
